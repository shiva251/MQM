import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit {
  users = [];
  users1 = [];
  apiUrl = 'https://jsonplaceholder.typicode.com/users';
  // db:any;
  constructor(private http: HttpClient) {}  
  isShown= false ; // hidden by default


  toggleShow() {
  this.users1 = this.users;
  this.isShown = true;
  
  }
   
  ngOnInit() {
    this.http.get<any[]>(this.apiUrl)
    .subscribe(data => {
            this.users = data;     
            // this.db=JSON.parse('this.users');
    });
    }
   clear() {
     this.users1 = [];
   } 
  
}
